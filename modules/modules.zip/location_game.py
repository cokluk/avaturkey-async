import random
import time
import asyncio
from modules.base_module import Module

class_name = "LocationGame"


class LocationGame(Module):
    prefix = "lg"

    def __init__(self, server):
        self.server = server
        self.commands = {"lst": self.game_list,
                         "cg": self.create_game,
                         "gi": self.game_info,
                         "invig": self.involve_in_game,
                         "en": self.enter_game,
                         "f": self.fight,
                         "br": self.beach_race,
                         "cn": self.canyon_race,
                         "sbr": self.snowboard_race,
                         "m": self.meerkat_game}
        self.games = {}

    def calculate_race_points(self, game_type, action, barrier_id):
        # Barrier/Object ID to Type Mapping
        obj_to_type = {
            "beachRace": {
                "fsh": "bonus", "n2o": "bonus", "pplr": "bonus",
                "stn": "barrier", "brl": "barrier", "wrpl": "portal",
                "ptl": "portal"
            },
            "canyonRace": {
                "rckt": "bonus", "n2o": "bonus", "wl": "bonus",
                "dnt": "barrier", "pt": "barrier", "rdf": "barrier",
                "ufo": "portal"
            },
            "snowboardRace": {
                "brl": "barrier", "sngb": "springboard"
            }
        }
        
        # Points mapping: move_id -> {type_id: points}
        points_map = {
            "beachRace": {
                "pickUp": {"bonus": 25, "barrier": -5, "portal": 5},
                "bypass": {"bonus": 5, "barrier": 25, "portal": 5},
                "usePortal": {"bonus": 5, "barrier": -5, "portal": 50}
            },
            "canyonRace": {
                "pickUp": {"bonus": 25, "barrier": -5, "portal": 5},
                "bypass": {"bonus": 5, "barrier": 25, "portal": 5},
                "usePortal": {"bonus": 5, "barrier": -5, "portal": 50}
            },
            "snowboardRace": {
                "jump": {"barrier": -5, "springboard": 25},
                "sitDown": {"barrier": 25, "springboard": -5},
                "trick": {"barrier": 75, "springboard": 75}
            }
        }
        
        game_map = obj_to_type.get(game_type, {})
        obj_type = game_map.get(barrier_id, barrier_id)
        
        move_id = action
        if isinstance(action, int):
            if game_type in ["beachRace", "canyonRace"]:
                move_id = ["pickUp", "bypass", "usePortal"][action - 1] if 1 <= action <= 3 else action
            elif game_type == "snowboardRace":
                move_id = ["jump", "sitDown", "trick"][action - 1] if 1 <= action <= 3 else action
        
        move_points = points_map.get(game_type, {}).get(move_id, {})
        return move_points.get(obj_type, 0), obj_type, move_id

    async def game_list(self, msg, client):
        """
        Aktif oyun listesini client'a gönderir.
        Client-side beklenen format:
        - lgid: oyun ID'si (str)
        - lgtp: oyun tipi ("fight", "beachRace", "canyonRace", "snowboardRace", "meerkat" vb.)
        - lgcid: oyun yaratıcısının user ID'si (str)
        - lgoid: rakip oyuncunun user ID'si (str) - opsiyonel
        - lgmrs: oyuncular listesi, her biri {"uid": user_id} formatında
        """
        print(f"[DEBUG] game_list called for client {client.uid}")
        game_list = []
        
        # Tüm aktif oyunları listele
        for game_id, game_data in self.games.items():
            # Tüm oyunları listele (Meerkat genellikle tek kişiliktir, ama listede görünebilir)
            gamers = []
            
            # İlk oyuncuyu ekle
            if game_data.get("first"):
                gamers.append({"uid": game_data["first"]})
            
            # İkinci oyuncuyu ekle (varsa)
            if game_data.get("second"):
                gamers.append({"uid": game_data["second"]})
            
            game_info = {
                "lgid": game_id,
                "lgtp": game_data.get("type", "fight"),
                "lgcid": game_data.get("first"),
                "lgmrs": gamers
            }
            
            # Rakip varsa ekle
            if game_data.get("second"):
                game_info["lgoid"] = game_data["second"]
            
            # Snowboard race için özel alan
            if game_data.get("type") == "snowboardRace":
                game_info["csid"] = "sbRS2"
                game_info["osid"] = "sbRS2"
            
            # Meerkat için özel alanlar
            if game_data.get("type") == "meerkat":
                game_info["gd"] = game_data.get("gd", 45000)
                game_info["mbc"] = game_data.get("mbc", 100)
                game_info["mi"] = game_data.get("mi", {})
            
            game_list.append(game_info)
        
        print(f"[DEBUG] Sending game_list with {len(game_list)} games to client {client.uid}")
        await client.send(["lg.lst", {"uid": client.uid, "glst": game_list}])

    async def create_game(self, msg, client):
        type_ = msg[2]["lgtp"]
        uid = msg[2]["gtid"]
        
        # Meerkat gibi tek oyunculu veya direkt başlatılan oyunlar için onay gerekmez
        if type_ != "meerkat":
            confirms = self.server.modules["cf"].confirms
            if client.uid not in confirms or \
               confirms[client.uid]["uid"] != uid or \
               not confirms[client.uid]["completed"]:
                print(f"[DEBUG] create_game: confirmation check failed for type {type_}")
                return
            del confirms[client.uid]
            
        if uid not in self.server.online:
            print(f"error 2: target user {uid} not online")
            return
        player1 = client
        player2 = self.server.online[uid]
        if type_ == "fight":
            await self.new_fight(player1, player2)
        elif type_ == "beachRace":
            await self.new_beach_race(player1, player2)
        elif type_ == "snowboardRace":
            await self.new_snowboard_race(player1, player2)
        elif type_ == "canyonRace":
            await self.new_canyon_race(player1, player2)
        elif type_ == "meerkat":
            await self.new_meerkat(player1)

    async def new_meerkat(self, player):
        while True:
            num = str(random.randint(1, 9999))
            if num not in self.games:
                break
        
        mi = {}
        for i in range(30):
            st = i * 1200 + random.randint(0, 500)
            # Spot names are likely m1, m2, ..., m6
            mi[str(i)] = {"id": str(i), "mid": f"m{random.randint(1, 6)}",
                          "st": st, "ht": st + 1500}

        self.games[num] = {"first": player.uid, "second": player.uid,
                           "room": num, "type": "meerkat",
                           "time": time.time(), "mi": mi,
                           "gd": 45000, "mbc": 100,
                           "old_rooms": {player.uid: player.room}}
        cr = player.uid
        room_name = f"game_meerkat_{num}"
        
        await player.send(["lg.f.jg", {"gmr": {"uid": cr, "fst": 0}}])
        # Note: type 16 and room entry now happen in enter_game
        await player.send(["lg.ng", {"gm": {"lgmrs": [{"uid": cr}],
                                            "lgcid": cr, "lgid": num,
                                            "lgtp": "meerkat", 
                                            "gd": self.games[num]["gd"],
                                            "mbc": self.games[num]["mbc"],
                                            "mi": mi}}])
        await player.send(["lg.cg", {"lgid": num}])

    async def new_canyon_race(self, player1, player2):
        while True:
            num = str(random.randint(1, 9999))
            if num not in self.games:
                break
        self.games[num] = {"first": player1.uid, "second": player2.uid,
                           "room": num, "type": "canyonRace", "fmoves": [],
                           "smoves": [], "fready": False, "sready": False,
                           "f_trnf": False, "s_trnf": False,
                           "fpoints": 0, "spoints": 0, "turn": 0, "np": "f",
                           "time": time.time(),
                           "old_rooms": {player1.uid: player1.room, player2.uid: player2.room}}
        cr = player1.uid
        op = player2.uid
        room_name = f"game_canyonRace_{num}"
        
        await player1.send(["lg.cn.jg", {"gmr": {"uid": cr, "brst": 0}}])
        for user in [player1, player2]:
            await user.send(["lg.ng", {"gm": {"lgmrs": [{"uid": cr, "brst": 0}, {"uid": op, "brst": 0}],
                                              "lgcid": cr, "lgid": num,
                                              "lgtp": "canyonRace",
                                              "lgoid": op}}])
        await player1.send(["lg.cg", {"lgid": num}])

    async def new_beach_race(self, player1, player2):
        while True:
            num = str(random.randint(1, 9999))
            if num not in self.games:
                break
        self.games[num] = {"first": player1.uid, "second": player2.uid,
                           "room": num, "type": "beachRace", "fmoves": [],
                           "smoves": [], "fready": False, "sready": False,
                           "f_trnf": False, "s_trnf": False,
                           "fpoints": 0, "spoints": 0, "turn": 0, "np": "f",
                           "time": time.time(),
                           "old_rooms": {player1.uid: player1.room, player2.uid: player2.room}}
        cr = player1.uid
        op = player2.uid
        room_name = f"game_beachRace_{num}"
        
        await player1.send(["lg.br.jg", {"gmr": {"uid": cr, "brst": 0}}])
        for user in [player1, player2]:
            await user.send(["lg.ng", {"gm": {"lgmrs": [{"uid": cr, "brst": 0}, {"uid": op, "brst": 0}],
                                              "lgcid": cr, "lgid": num,
                                              "lgtp": "beachRace",
                                              "lgoid": op}}])
        await player1.send(["lg.cg", {"lgid": num}])

    async def new_snowboard_race(self, player1, player2):
        while True:
            num = str(random.randint(1, 9999))
            if num not in self.games:
                break
        self.games[num] = {"first": player1.uid, "second": player2.uid,
                           "room": num, "type": "snowboardRace", "fmoves": [],
                           "smoves": [], "fready": False, "sready": False,
                           "f_trnf": False, "s_trnf": False,
                           "fpoints": 0, "spoints": 0, "turn": 0, "np": "f",
                           "time": time.time(),
                           "old_rooms": {player1.uid: player1.room, player2.uid: player2.room}}
        cr = player1.uid
        op = player2.uid
        room_name = f"game_snowboardRace_{num}"
        
        await player1.send(["lg.sbr.jg", {"gmr": {"uid": cr, "sbid": "sbRS2", "brst": 0}}])
        for user in [player1, player2]:
            await user.send(["lg.ng", {"gm": {"lgmrs": [{"uid": cr, "sbid": "sbRS2", "brst": 0}, {"uid": op, "sbid": "sbRS2", "brst": 0}],
                                              "lgcid": cr, "lgid": num,
                                              "lgtp": "snowboardRace",
                                              "osid": "sbRS2", "csid": "sbRS2",
                                              "lgoid": op}}])
        await player1.send(["lg.cg", {"lgid": num}])

    async def new_fight(self, player1, player2):
        while True:
            num = str(random.randint(1, 9999))
            if num not in self.games:
                break
        self.games[num] = {"first": player1.uid, "second": player2.uid,
                           "room": num, "type": "fight", "fmoves": [],
                           "smoves": [], "fready": False, "sready": False,
                           "fpoints": 0, "spoints": 0, "turn": 0, "np": "f",
                           "time": time.time(),
                           "old_rooms": {player1.uid: player1.room, player2.uid: player2.room}}
        cr = player1.uid
        op = player2.uid
        room_name = f"game_fight_{num}"
        
        await player1.send(["lg.f.jg", {"gmr": {"uid": cr, "fml": None,
                                                "fst": 0}}])
        for user in [player1, player2]:
            await user.send(["lg.ng", {"gm": {"lgmrs": [{"uid": cr}, {"uid": op}],
                                              "lgcid": cr, "lgid": num,
                                              "lgtp": "fight"}}])
        await player1.send(["lg.cg", {"lgid": num}])

    async def game_info(self, msg, client):
        num = msg[2]["lgid"]
        if num not in self.games:
            return
        game = self.games[num]
        cr = game["first"]
        op = game["second"]
        if game["type"] == "fight":
            await client.send(["lg.gi", {"gm": {"lgmrs": [{"uid": cr, "fml": None, "fst": 0}, {"uid": op, "fml": None, "fst": 0}],
                                                "fohp": 0, "lgcid": cr,
                                                "lgid": num, "lgtp": "fight",
                                                "fchp": 0, "fmt": 5,
                                                "lgoid": op}}])
        elif game["type"] == "beachRace":
            await client.send(["lg.gi", {"gm": {"lgmrs": [{"uid": cr, "brst": 0}, {"uid": op, "brst": 0}], "lgcid": cr, "lgid": num, "lgtp": "beachRace", "lgoid": op}}])
        elif game["type"] == "canyonRace":
            await client.send(["lg.gi", {"gm": {"lgmrs": [{"uid": cr, "brst": 0}, {"uid": op, "brst": 0}], "lgcid": cr, "lgid": num, "lgtp": "canyonRace", "lgoid": op}}])
        elif game["type"] == "snowboardRace":
            await client.send(["lg.gi", {"gm": {"lgmrs": [{"uid": cr, "brst": 0, "sbid": "sbRS2"}, {"uid": op, "brst": 0, "sbid": "sbRS2"}], "lgcid": cr, "lgid": num, "csid": "sbRS2", "osid": "sbRS2", "lgtp": "snowboardRace", "lgoid": op}}])
        elif game["type"] == "meerkat":
            await client.send(["lg.gi", {"gm": {"lgmrs": [{"uid": cr, "fst": 0}], "lgcid": cr, "lgid": num, "lgtp": "meerkat", "lgoid": op, "gd": game["gd"], "mbc": game["mbc"], "mi": game["mi"]}}])

    async def involve_in_game(self, msg, client):
        num = msg[2]["lgid"]
        if num not in self.games:
            return
        game = self.games[num]
        op = self.server.online[game["second"]]
        await op.send(["lg.invig", {"uid": client.uid, "lgid": num, "rq": False}])

    async def enter_game(self, msg, client):
        num = msg[2]["lgid"]
        if num not in self.games:
            return
        game = self.games[num]
        
        # Save old room if not already saved (e.g. for the opponent joining)
        if "old_rooms" not in game:
            game["old_rooms"] = {}
        
        old_room = client.room
        if client.uid not in game["old_rooms"]:
            game["old_rooms"][client.uid] = old_room
            
        # Cleanly leave the current room before entering the game room
        if old_room:
            try:
                if old_room.startswith("house"):
                    await self.server.modules["h"].leave_room(client)
                else:
                    await self.server.modules["o"].leave_room(client)
            except Exception as e:
                print(f"[ERROR] enter_game: leave_room failed: {e}")

        users = [self.server.online[game["first"]],
                 self.server.online[game["second"]]]
        
        room_name = f"game_{game['type']}_{num}"
        # Update server rooms
        if room_name not in self.server.rooms:
            self.server.rooms[room_name] = []
        if client.uid not in self.server.rooms[room_name]:
            self.server.rooms[room_name].append(client.uid)
        client.room = room_name

        for user in users:
            if game["type"] == "fight":
                await user.send(["lg.f.jg", {"gmr": {"uid": client.uid, "fml": None, "fst": 0}}])
                await user.send([room_name, client.uid], type_=16)
            elif game["type"] == "canyonRace":
                await user.send(["lg.cn.jg", {"gmr": {"uid": client.uid, "brst": 0}}])
                await user.send([room_name, client.uid], type_=16)
            elif game["type"] == "beachRace":
                await user.send(["lg.br.jg", {"gmr": {"uid": client.uid, "brst": 0}}])
                await user.send([room_name, client.uid], type_=16)
            elif game["type"] == "snowboardRace":
                await user.send(["lg.sbr.jg", {"gmr": {"uid": client.uid, "brst": 0, "sbid": "sbRS2"}}])
                await user.send([room_name, client.uid], type_=16)
            elif game["type"] == "meerkat":
                await user.send(["lg.f.jg", {"gmr": {"uid": client.uid, "fst": 0}}])
                await user.send([room_name, client.uid], type_=16)
        await client.send(["lg.en", {"lgid": num}])
        for user in users:
            await user.send(["lg.eing", {"lgid": num,
                                         "gmr": {"uid": client.uid}}])

    async def exit_game(self, room, client):
        num = room.split("_")[-1]
        await client.send(["lg.lvdg", {"uid": client.uid, "lgid": num}])
        await client.send(["lg.gf", {"lgid": num}])
        if num not in self.games:
            return
        game = self.games[num]
        
        # Restore old room for THIS client using proper module join
        if "old_rooms" in game and client.uid in game["old_rooms"]:
            old_room = game["old_rooms"][client.uid]
            if old_room:
                 if old_room.startswith("house"):
                      await self.server.modules["h"].join_room(client, old_room)
                 else:
                      await self.server.modules["o"].join_room(client, old_room)
            else:
                 await self.server.modules["o"].join_room(client, "street_city_1")

        if client.uid == game["first"]:
            uid = game["second"]
        else:
            uid = game["first"]
        
        if uid in self.server.online:
            tmp = self.server.online[uid]
            user_data = await self.server.get_user_data(uid)
            if game["type"] == "fight":
                await tmp.send(["lg.f.fin", {"res": {"slvr": user_data["slvr"],
                                                     "enrg": user_data["enrg"],
                                                     "emd": user_data["emd"],
                                                     "gld": user_data["gld"]},
                                             "fohp": 0, "fwnr": None, "fchp": 0}])
                await tmp.send(["lg.f.lv", {"gtid": client.uid}])
            elif game["type"] == "snowboardRace":
                await tmp.send(["lg.sbr.gfin", {"res": {"slvr": user_data["slvr"],
                                                        "enrg": user_data["enrg"],
                                                        "emd": user_data["emd"],
                                                        "gld": user_data["gld"]},
                                                "rwnr": None}])
                await tmp.send(["lg.sbr.lv", {"gtid": client.uid}])
            elif game["type"] == "canyonRace":
                await tmp.send(["lg.cn.gfin", {"res": {"slvr": user_data["slvr"],
                                                       "enrg": user_data["enrg"],
                                                       "emd": user_data["emd"],
                                                       "gld": user_data["gld"]},
                                               "rwnr": None}])
                await tmp.send(["lg.cn.lv", {"gtid": client.uid}])
            elif game["type"] == "beachRace":
                await tmp.send(["lg.br.gfin", {"res": {"slvr": user_data["slvr"],
                                                       "enrg": user_data["enrg"],
                                                       "emd": user_data["emd"],
                                                       "gld": user_data["gld"]},
                                               "rwnr": None}])
                await tmp.send(["lg.br.lv", {"gtid": client.uid}])
            elif game["type"] == "meerkat":
                await tmp.send(["lg.m.gfc", {"awd": None, "tid": None}])
                await tmp.send(["lg.f.lv", {"gtid": client.uid}])
            
            # Also restore room for the other player if they were in the game room
            if "old_rooms" in game and uid in game["old_rooms"]:
                old_room = game["old_rooms"][uid]
                if tmp.room == room: # Only if they are still in the game room
                    if old_room:
                        if old_room.startswith("house"):
                            await self.server.modules["h"].join_room(tmp, old_room)
                        else:
                            await self.server.modules["o"].join_room(tmp, old_room)
                    else:
                        await self.server.modules["o"].join_room(tmp, "street_city_1")

        # Cleanup game from memory LAST
        del self.games[num]
        # Cleanup virtual room from server tracking is handled by join_room/leave_room logic

    async def canyon_race(self, msg, client):
        subcommand = msg[1].split(".")[-1]
        if subcommand == "rdy":
            return await self.canyon_ready(msg, client)
        elif subcommand == "trnf":  # turn finished
            return await self.canyon_turn_finished(msg, client)
        elif subcommand in ["strt", "fin"]:
            return
        else:
            print(f"Command {msg[1]} not found")

    async def snowboard_race(self, msg, client):
        subcommand = msg[1].split(".")[-1]
        if subcommand == "rdy":
            return await self.snow_ready(msg, client)
        elif subcommand == "trnf":  # turn finished
            return await self.snow_turn_finished(msg, client)
        elif subcommand in ["strt", "fin"]:
            return
        else:
            print(f"Command {msg[1]} not found")

    async def beach_race(self, msg, client):
        subcommand = msg[1].split(".")[-1]
        if subcommand == "rdy":
            return await self.beach_ready(msg, client)
        elif subcommand == "trnf":  # turn finished
            return await self.beach_turn_finished(msg, client)
        elif subcommand in ["strt", "fin"]:
            return
        else:
            print(f"Command {msg[1]} not found")

    async def fight(self, msg, client):
        subcommand = msg[1].split(".")[-1]
        if subcommand == "rdy":
            return await self.fight_ready(msg, client)
        elif subcommand == "trnf":  # turn finished
            return await self.turn_finished(msg, client)
        else:
            print(f"Command {msg[1]} not found")

    async def meerkat_game(self, msg, client):
        subcommand = msg[1].split(".")[-1]
        if subcommand == "sgc":  # start game command
            return await self.meerkat_start(msg, client)
        elif subcommand == "fgc":  # finish game command
            return await self.meerkat_finish(msg, client)
        elif subcommand == "sac":  # send award command
            return await self.meerkat_send_award(msg, client)
        else:
            print(f"Command {msg[1]} not found")

    async def meerkat_start(self, msg, client):
        num = msg[0].split("_")[-1]
        if num not in self.games:
            return
        await client.send(["lg.m.gsc", {}])

    async def meerkat_finish(self, msg, client):
        num = msg[0].split("_")[-1]
        if num not in self.games:
            return
        game = self.games[num]
        
        # Get hits from game result (gr)
        gr = msg[2].get("gr", {})
        ri = gr.get("ri", [])
        hits = 0
        for item in ri:
            if item.get("mi") is not None:
                hits += 1
        
        # Win condition: thresholds from gamesConfig.xml
        # ma1: 10 hits, ma2: 20 hits, ma3: 30 hits
        if hits >= 30:
            # ma3: Bear
            await client.send(["lg.m.gfc", {"awd": "mkBear", "tid": "bear"}])
        elif hits >= 20:
            # ma2: Balloon (pick one randomly)
            balloon = random.choice(["mkBllnBl", "mkBllnRd", "mkBllnYw"])
            await client.send(["lg.m.gfc", {"awd": balloon, "tid": "balloon"}])
        elif hits >= 10:
            # ma1: Lollypop (pick one randomly)
            lollypop = random.choice(["mkLllppBl", "mkLllppRd"])
            await client.send(["lg.m.gfc", {"awd": lollypop, "tid": "lollypop"}])
        else:
            # Loss or partially hit
            await client.send(["lg.m.gfc", {"awd": None, "tid": None}])

    async def meerkat_send_award(self, msg, client):
        num = msg[0].split("_")[-1]
        if num not in self.games:
            return
        # notify award sent successfully
        await client.send(["lg.m.asc", {}])

    async def canyon_turn_finished(self, msg, client):
        num = msg[0].split("_")[-1]
        if num not in self.games:
            return
        game = self.games[num]
        if client.uid == game["first"]:
            game["f_trnf"] = True
        else:
            game["s_trnf"] = True
        
        if game["f_trnf"] and game["s_trnf"]:
            game["f_trnf"] = False
            game["s_trnf"] = False
            await self.canyon_next_turn(num)

    async def snow_turn_finished(self, msg, client):
        num = msg[0].split("_")[-1]
        if num not in self.games:
            return
        game = self.games[num]
        if client.uid == game["first"]:
            game["f_trnf"] = True
        else:
            game["s_trnf"] = True
        
        if game["f_trnf"] and game["s_trnf"]:
            game["f_trnf"] = False
            game["s_trnf"] = False
            await self.snow_next_turn(num)

    async def beach_turn_finished(self, msg, client):
        num = msg[0].split("_")[-1]
        if num not in self.games:
            return
        game = self.games[num]
        if client.uid == game["first"]:
            game["f_trnf"] = True
        else:
            game["s_trnf"] = True
        
        if game["f_trnf"] and game["s_trnf"]:
            game["f_trnf"] = False
            game["s_trnf"] = False
            await self.beach_next_turn(num)

    async def snow_ready(self, msg, client):
        num = msg[0].split("_")[-1]
        if num not in self.games:
            return
        game = self.games[num]
        if client.uid == game["first"]:
            cr = True
            moves = game["fmoves"]
            game["fready"] = True
        else:
            cr = False
            moves = game["smoves"]
            game["sready"] = True
        
        actions = msg[2]["rgact"]
        for i in range(len(actions)):
            moves.append(actions[i])
            
        await client.send(["lg.sbr.rdy", {"scs": True, "brst": 1}])
        if cr:
            while not (game["fready"] and game["sready"]):
                await asyncio.sleep(0.1)
            users = [self.server.online[game["first"]],
                     self.server.online[game["second"]]]
            for user in users:
                await user.send(["lg.sbr.strt", {"lgcid": game["first"], "lgoid": game["second"]}])
            await self.snow_next_turn(num)

    async def canyon_ready(self, msg, client):
        num = msg[0].split("_")[-1]
        if num not in self.games:
            return
        game = self.games[num]
        if client.uid == game["first"]:
            cr = True
            moves = game["fmoves"]
            game["fready"] = True
        else:
            cr = False
            moves = game["smoves"]
            game["sready"] = True
        actions = msg[2]["rgact"]
        barriers = msg[2]["rgbrr"]
        for i in range(len(actions)):
            moves.append({"rgact": actions[i], "rgbrr": barriers[i]})
        await client.send(["lg.cn.rdy", {"scs": True, "brst": 1}])
        if cr:
            while not (game["fready"] and game["sready"]):
                await asyncio.sleep(0.1)
            data = msg[2]
            users = [self.server.online[game["first"]],
                     self.server.online[game["second"]]]
            for user in users:
                await user.send(["lg.cn.strt", {"lgcid": game["first"], "lgoid": game["second"]}])
            await self.canyon_next_turn(num)

    async def beach_ready(self, msg, client):
        num = msg[0].split("_")[-1]
        if num not in self.games:
            return
        game = self.games[num]
        if client.uid == game["first"]:
            cr = True
            moves = game["fmoves"]
            game["fready"] = True
        else:
            cr = False
            moves = game["smoves"]
            game["sready"] = True
        actions = msg[2]["rgact"]
        barriers = msg[2]["rgbrr"]
        for i in range(len(actions)):
            moves.append({"rgact": actions[i], "rgbrr": barriers[i]})
        await client.send(["lg.br.rdy", {"scs": True, "brst": 1}])
        if cr:
            while not (game["fready"] and game["sready"]):
                await asyncio.sleep(0.1)
            data = msg[2]
            users = [self.server.online[game["first"]],
                     self.server.online[game["second"]]]
            for user in users:
                await user.send(["lg.br.strt", {"lgcid": game["first"], "lgoid": game["second"]}])
            await self.beach_next_turn(num)

    async def fight_ready(self, msg, client):
        num = msg[0].split("_")[-1]
        if num not in self.games:
            return
        game = self.games[num]
        if client.uid == game["first"]:
            cr = True
            moves = game["fmoves"]
            game["fready"] = True
        else:
            cr = False
            moves = game["smoves"]
            game["sready"] = True
        for move in msg[2]["fml"]:
            moves.append(move["fid"])
        await client.send(["lg.f.rdy", {"scs": True, "fst": 1}])
        if cr:
            while not (game["fready"] and game["sready"]):
                await asyncio.sleep(0.1)
            data = msg[2]
            users = [self.server.online[game["first"]],
                     self.server.online[game["second"]]]
            for user in users:
                await user.send(["lg.f.strt", {"lgcid": game["first"],
                                               "ctpy": data["ctpy"],
                                               "ctpx": data["ctpx"],
                                               "otpx": data["otpx"],
                                               "otpy": data["otpy"],
                                               "lgoid": game["second"]}])
            await self._next_turn(num)

    async def turn_finished(self, msg, client):
        num = msg[0].split("_")[-1]
        if num not in self.games:
            return
        await self._next_turn(num)

    def has_block(self, f, s):
        if (f == 1 and s == 3) or (f == 2 and s == 4):
            return True
        return False

    async def snow_next_turn(self, num):
        game = self.games[num]
        turn = game["turn"]
        if turn == 5:
            if game["fpoints"] > game["spoints"]:
                winner = game["first"]
            elif game["spoints"] > game["fpoints"]:
                winner = game["second"]
            else:
                winner = None
            users = [self.server.online[game["first"]],
                     self.server.online[game["second"]]]
            
            # Send 'fin' to trigger finish animation
            for user in users:
                await user.send(["lg.sbr.fin", {}])
            
            # Wait for finish animation to play
            await asyncio.sleep(4)
            
            for user in users:
                user_data = await self.server.get_user_data(user.uid)
                await user.send(["lg.sbr.gfin", {"res": {"slvr": user_data["slvr"],
                                                         "enrg": user_data["enrg"],
                                                         "emd": user_data["emd"],
                                                         "gld": user_data["gld"]},
                                                 "rgwr": {"rb": 0, "slvr": 0,
                                                          "enrg": 0, "emd": 0,
                                                          "gld": 0},
                                                 "rwnr": winner,
                                                 "fchp": game["fpoints"],
                                                 "fohp": game["spoints"]}])
                await user.send(["lg.lvdg", {"uid": user.uid, "lgid": num}])
                await user.send(["lg.gf", {"lgid": num}])
                if "old_rooms" in game and user.uid in game["old_rooms"]:
                    old_room = game["old_rooms"][user.uid]
                    if old_room.startswith("house"):
                        await self.server.modules["h"].join_room(user, old_room)
                    else:
                        await self.server.modules["o"].join_room(user, old_room)
            
            del self.games[num]
            return
        f = game["fmoves"][turn]
        s_orig = game["smoves"][turn]
        s = s_orig
        
        # Turn 1 and 2 are barriers (index 1 and 2)
        if turn == 1 or turn == 2:
            barrier_id = "brl"
        else:
            barrier_id = "sngb"

        fp, f_type, f_mid = self.calculate_race_points("snowboardRace", f, barrier_id)
        sp, s_type, s_mid = self.calculate_race_points("snowboardRace", s, barrier_id)
        
        game["fpoints"] += fp
        game["spoints"] += sp
        users = [self.server.online[game["first"]],
                 self.server.online[game["second"]]]
        
        await asyncio.sleep(3)
        for user in users:
            await user.send(["lg.sbr.ntrn", {"rtrn": {"ti": [{"uid": game["first"], "mid": f_mid, "bid": f_type, "tpts": game["fpoints"], "pts": fp},
                                                             {"uid": game["second"], "mid": s_mid, "bid": s_type, "tpts": game["spoints"], "pts": sp}], "tidx": turn+1}}])
        game["turn"] += 1

    async def canyon_next_turn(self, num):
        game = self.games[num]
        turn = game["turn"]
        if turn == 5:
            if game["fpoints"] > game["spoints"]:
                winner = game["first"]
            elif game["spoints"] > game["fpoints"]:
                winner = game["second"]
            else:
                winner = None
            users = [self.server.online[game["first"]],
                     self.server.online[game["second"]]]
            
            # Send 'fin' to trigger finish animation
            for user in users:
                await user.send(["lg.cn.fin", {}])
            
            # Wait for finish animation
            await asyncio.sleep(4)

            for user in users:
                user_data = await self.server.get_user_data(user.uid)
                await user.send(["lg.cn.gfin", {"res": {"slvr": user_data["slvr"],
                                                        "enrg": user_data["enrg"],
                                                        "emd": user_data["emd"],
                                                        "gld": user_data["gld"]},
                                                "rgwr": {"rb": 0, "slvr": 0,
                                                         "enrg": 0, "emd": 0,
                                                         "gld": 0},
                                                "rwnr": winner,
                                                "fchp": game["fpoints"],
                                                "fohp": game["spoints"]}])
                await user.send(["lg.lvdg", {"uid": user.uid, "lgid": num}])
                await user.send(["lg.gf", {"lgid": num}])
                if "old_rooms" in game and user.uid in game["old_rooms"]:
                    old_room = game["old_rooms"][user.uid]
                    if old_room.startswith("house"):
                        await self.server.modules["h"].join_room(user, old_room)
                    else:
                        await self.server.modules["o"].join_room(user, old_room)            
            del self.games[num]
            return
        f = game["fmoves"][turn]["rgact"]
        s_orig = game["smoves"][turn]["rgact"]
        
        # Player 1 faces Player 2's barrier and vice versa
        f_barrier_id = game["smoves"][turn]["rgbrr"]
        s_barrier_id = game["fmoves"][turn]["rgbrr"]

        fp, f_bid_type, f_mid = self.calculate_race_points("canyonRace", f, f_barrier_id)
        sp, s_bid_type, s_mid = self.calculate_race_points("canyonRace", s_orig, s_barrier_id)
        
        game["fpoints"] += fp
        game["spoints"] += sp
        users = [self.server.online[game["first"]],
                 self.server.online[game["second"]]]
        await asyncio.sleep(3)
        for user in users:
            await user.send(["lg.cn.ntrn", {"rtrn": {"ti": [{"uid": game["first"], "mid": f_mid, "bid": f_bid_type, "tpts": game["fpoints"], "pts": fp},
                                                            {"uid": game["second"], "mid": s_mid, "bid": s_bid_type, "tpts": game["spoints"], "pts": sp}], "tidx": turn+1}}])
        game["turn"] += 1

    async def beach_next_turn(self, num):
        game = self.games[num]
        turn = game["turn"]
        if turn == 5:
            if game["fpoints"] > game["spoints"]:
                winner = game["first"]
            elif game["spoints"] > game["fpoints"]:
                winner = game["second"]
            else:
                winner = None
            users = [self.server.online[game["first"]],
                     self.server.online[game["second"]]]
            
            # Send 'fin' to trigger finish animation
            for user in users:
                await user.send(["lg.br.fin", {}])
            
            # Wait for finish animation
            await asyncio.sleep(4)

            for user in users:
                user_data = await self.server.get_user_data(user.uid)
                await user.send(["lg.br.gfin", {"res": {"slvr": user_data["slvr"],
                                                        "enrg": user_data["enrg"],
                                                        "emd": user_data["emd"],
                                                        "gld": user_data["gld"]},
                                                "rgwr": {"rb": 0, "slvr": 0,
                                                         "enrg": 0, "emd": 0,
                                                         "gld": 0},
                                                "rwnr": winner,
                                                "fchp": game["fpoints"],
                                                "fohp": game["spoints"]}])
                await user.send(["lg.lvdg", {"uid": user.uid, "lgid": num}])
                await user.send(["lg.gf", {"lgid": num}])
                if "old_rooms" in game and user.uid in game["old_rooms"]:
                    old_room = game["old_rooms"][user.uid]
                    if old_room.startswith("house"):
                        await self.server.modules["h"].join_room(user, old_room)
                    else:
                        await self.server.modules["o"].join_room(user, old_room)
            
            del self.games[num]
            return
        f = game["fmoves"][turn]["rgact"]
        s_orig = game["smoves"][turn]["rgact"]

        # Player 1 faces Player 2's barrier and vice versa
        f_barrier_id = game["smoves"][turn]["rgbrr"]
        s_barrier_id = game["fmoves"][turn]["rgbrr"]

        fp, f_bid_type, f_mid = self.calculate_race_points("beachRace", f, f_barrier_id)
        sp, s_bid_type, s_mid = self.calculate_race_points("beachRace", s_orig, s_barrier_id)

        game["fpoints"] += fp
        game["spoints"] += sp
        users = [self.server.online[game["first"]],
                 self.server.online[game["second"]]]
        await asyncio.sleep(3)
        for user in users:
            await user.send(["lg.br.ntrn", {"rtrn": {"ti": [{"uid": game["first"], "mid": f_mid, "bid": f_bid_type, "tpts": game["fpoints"], "pts": fp},
                                                            {"uid": game["second"], "mid": s_mid, "bid": s_bid_type, "tpts": game["spoints"], "pts": sp}], "tidx": turn+1}}])
        game["turn"] += 1

    async def _next_turn(self, num):
        game = self.games[num]
        turn = game["turn"]
        if turn == 5:
            if game["fpoints"] > game["spoints"]:
                winner = game["first"]
            elif game["spoints"] > game["fpoints"]:
                winner = game["second"]
            else:
                winner = None
            users = [self.server.online[game["first"]],
                     self.server.online[game["second"]]]
            for user in users:
                user_data = await self.server.get_user_data(user.uid)
                await user.send(["lg.f.fin", {"res": {"slvr": user_data["slvr"],
                                                      "enrg": user_data["enrg"],
                                                      "emd": user_data["emd"],
                                                      "gld": user_data["gld"]},
                                              "fohp": game["spoints"],
                                              "fgwr": {"rb": 0, "slvr": 0,
                                                       "enrg": 0, "emd": 0,
                                                       "gld": 0},
                                              "fwnr": winner,
                                              "fchp": game["fpoints"]}])
                await user.send(["lg.lvdg", {"uid": user.uid, "lgid": num}])
                await user.send(["lg.gf", {"lgid": num}])
                if "old_rooms" in game and user.uid in game["old_rooms"]:
                    old_room = game["old_rooms"][user.uid]
                    if old_room.startswith("house"):
                        await self.server.modules["h"].join_room(user, old_room)
                    else:
                        await self.server.modules["o"].join_room(user, old_room)
            
            del self.games[num]
            return
        f = game["fmoves"][turn]
        s_orig = game["smoves"][turn]
        s = s_orig
        fp = 0
        sp = 0
        if game["np"] == "f":
            attacker = game["first"]
            if not self.has_block(f, s_orig):
                if f == 1:
                    s = 98
                    fp = 10
                elif f == 2:
                    s = 99
                    fp = 5
        else:
            attacker = game["second"]
            s = s_orig
            if not self.has_block(s, f):
                if s == 1:
                    f = 98
                    sp = 10
                elif s == 2:
                    f = 99
                    sp = 5
        game["fpoints"] += fp
        game["spoints"] += sp
        users = [self.server.online[game["first"]],
                 self.server.online[game["second"]]]
        await asyncio.sleep(3)
        for user in users:
            await user.send(["lg.f.ntrn", {"fstrn": {"fgmv": {"fid": f,
                                                              "ftrn": turn+1},
                                                     "fchp": fp},
                                           "fgcaid": attacker,
                                           "fotrn": {"fgmv": {"fid": s,
                                                              "ftrn": turn+1},
                                                     "fohp": sp}}])
        if game["np"] == "s" or s_orig in [3, 4]:
            game["turn"] += 1
            game["np"] = "f"
        else:
            game["np"] = "s"